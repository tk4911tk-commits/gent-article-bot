# GENT LINE Bot 実装ガイド

## 🎯 全体フロー

```
【毎週日曜20時】GitHub Actions トリガー
  ↓
【トピック生成】Claude API で 3-4 本提案
  ↓
【LINE 送信】topics をメッセージで KOI に配信
  ↓
【KOI が返信】「①で」「②で」など番号で返信
  ↓
【Webhook 受信】Vercel エンドポイントが受け取り
  ↓
【ドラフト生成】Claude API でドラフト自動生成
  ↓
【LINE 返信】KOI にドラフト送信（複数メッセージ）
  ↓
【note で仕上げ】KOI が手直し → 公開
  ↓
【microCMS へ URL 貼付】完了
```

---

## 📋 実装の 3 つのフェーズ

### ✅ フェーズ 1：トピック自動生成（本体）
**状態：完成**
- `weekly-topic-generator.js` ✅
- `weekly-topic-bot.yml` ✅
- GitHub Actions スケジュール設定 ✅

**必要な作業：**
1. GitHub リポジトリに `.github/workflows/weekly-topic-bot.yml` を配置
2. GitHub Secrets に 3 つを登録：
   - `ANTHROPIC_API_KEY`
   - `LINE_CHANNEL_ACCESS_TOKEN`
   - `LINE_USER_ID`（KOI の LINE ID）
3. `src/weekly-topic-generator.js` を配置
4. `data/learning-articles.md` を配置

### ⏳ フェーズ 2：LINE Webhook 受信（次のステップ）
**状態：次に実装**
- Vercel Function で webhook エンドポイントを作成
- LINE からのメッセージを受け取り、番号を解析

### ⏳ フェーズ 3：ドラフト自動生成（フェーズ 2 の後）
**状態：次に実装**
- Claude API でドラフト生成
- LINE で返信（複数メッセージに分割）

---

## 🔐 GitHub Secrets 登録方法

1. **GitHub リポジトリ** → Settings → Secrets and variables → Actions
2. 以下の 3 つを New repository secret で追加：

| Secret 名 | 値 |
|---|---|
| `ANTHROPIC_API_KEY` | [Anthropic Console](https://console.anthropic.com) から API Key 取得 |
| `LINE_CHANNEL_ACCESS_TOKEN` | [LINE Developers Console](https://developers.line.biz) → Channel settings |
| `LINE_USER_ID` | [LINE Bot Designer](https://developers.line.biz) で自分のユーザー ID を確認 |

### LINE User ID の確認方法
```
LINE Bot に自分で話しかける
  ↓
メッセージが返ってくる（この時点で Bot があなたのユーザー ID を認識）
  ↓
LINE Developers コンソール → Bot logs で確認
```

---

## 📁 リポジトリ構成（完成形）

```
gent-article-bot/
├── .github/workflows/
│   └── weekly-topic-bot.yml              ← トピック自動生成スケジュール
├── src/
│   ├── weekly-topic-generator.js         ← トピック生成メイン
│   ├── draft-generator.js                ← ドラフト生成（フェーズ 3）
│   └── line-webhook-handler.js           ← Webhook 受信（フェーズ 2）
├── data/
│   ├── learning-articles.md              ← 学習用既存記事
│   └── draft-templates.json              ← ドラフト生成テンプレート（フェーズ 3）
├── vercel.json                           ← Vercel デプロイ設定
├── package.json
├── .env.example
└── README.md
```

---

## 🚀 次のステップ

### Step A：GitHub Actions で自動トピック配信を動かす（本週中）
1. リポジトリに上記ファイルを配置
2. GitHub Secrets 3 つを登録
3. 日曜 20 時に実行されるか確認

### Step B：Vercel で Webhook 受信を設定（次週）
1. Vercel にプロジェクト作成
2. `api/webhook.js` を実装（LINEメッセージ受信）
3. LINE Developers で Webhook URL を Vercel エンドポイントに設定

### Step C：ドラフト自動生成を実装（その次）
1. Webhook 受信時に Claude API でドラフト生成
2. LINE で複数メッセージで返信

---

## 💬 KOI への使い方説明

```
【毎週日曜20時】
LINE に「今週のトピック池」が届く
  ↓
【KOI が返信】
「①で」または「②で」など、好きな番号を返信
  ↓
【AI が自動生成】
数分以内にドラフトが LINE に返ってくる
  ↓
【note で仕上げ】
LINE で受け取ったドラフトを、note で手直し
  ↓
【完了】
microCMS に URL 貼付
```

---

## 📊 テスト方法

### 手動実行テスト
```bash
# GitHub Actions の workflow_dispatch を使って、ボタンから手動実行できます
# Settings → Actions → Weekly GENT Article Topic Bot → Run workflow
```

### ローカルテスト
```bash
# 1. .env ファイルを作成
cp .env.example .env
# ANTHROPIC_API_KEY と LINE_CHANNEL_ACCESS_TOKEN を入力

# 2. 実行
node src/weekly-topic-generator.js
```

---

## ⚠️ トラブルシューティング

### トピックが LINE に届かない
- GitHub Actions ログを確認（Settings → Actions → Workflows）
- Secrets が正しく登録されているか確認
- Anthropic API の残高を確認

### LINE メッセージが文字化けしている
- JSON フォーマットが正しいか確認（`lineMessages` の構造）
- LINE API v2 の仕様に合わせているか確認

---

## 📝 今後のカスタマイズ例

- [ ] トピック池から「推しジャンル」を学習（KOI の選択履歴から）
- [ ] ドラフト生成時に「文字数目安」をカスタマイズ可能に
- [ ] 過去のドラフトから「改善点」を自動抽出して次に活かす
- [ ] Notion ダッシュボードで投稿スケジュール管理
