# GENT LINE Bot - 記事量産半自動化システム

恋愛コーチング事業「GENT」の記事を**週1-2本ペース**で半自動生成・配信するシステムです。

## 🎯 何ができるの？

```
毎週日曜夜20時
  ↓
📱 LINE に「今週のおすすめトピック 3-4 本」が自動で届く
  ↓
💬 「①で」と返信
  ↓
🤖 AI が自動でドラフト生成
  ↓
✍️ note で手直ししたら完了
```

## 📋 ジャンル

- **会話・コミュニケーション**
- **身だしなみ・清潔感**
- **LINE・マッチングアプリ**
- **実話・事例紹介**
- **性（キス・SEX など）** ← 新ジャンル

## 🚀 セットアップ

### 1. リポジトリクローン
```bash
git clone https://github.com/your-account/gent-article-bot.git
cd gent-article-bot
```

### 2. GitHub Secrets を 3 つ登録
Settings → Secrets and variables → Actions で以下を追加：
- `ANTHROPIC_API_KEY`
- `LINE_CHANNEL_ACCESS_TOKEN`
- `LINE_USER_ID`

[詳細はこちら](./IMPLEMENTATION_GUIDE.md)

### 3. テスト実行
```bash
# ローカルテスト
npm install
node src/weekly-topic-generator.js
```

## 📅 自動実行スケジュール

- **毎週日曜夜 20 時（JST）** に自動実行
- 手動実行：GitHub Actions → Weekly GENT Article Topic Bot → "Run workflow"

## 📁 ファイル構成

```
gent-article-bot/
├── .github/workflows/
│   └── weekly-topic-bot.yml           # GitHub Actions トリガー設定
├── src/
│   └── weekly-topic-generator.js      # トピック生成メインスクリプト
├── data/
│   └── learning-articles.md           # 学習用既存記事テンプレート
├── logs/                              # 実行ログ（自動生成）
├── package.json
├── .env.example
├── IMPLEMENTATION_GUIDE.md            # 詳細なセットアップガイド
└── README.md                          # このファイル
```

## 📖 使い方

### トピックが LINE に届いたら

```
GENT Bot
📌 今週のトピック池

今週のおすすめ記事トピック 3 本です。どれで執筆しますか？

【1】キスが上手い男の秘密：相手の反応を読む技術
📂 ジャンル：性
🎨 文体：運営者風
...
```

### 返信する

```
あなた
①で
```

### ドラフトが自動で返ってくる

```
GENT Bot
【ドラフト】キスが上手い男の秘密：相手の反応を読む技術

---
[記事本文が複数メッセージで送られてきます]
---
```

### note で仕上げて公開

```
1. LINE で受け取ったドラフトをコピー
2. note で新規記事を作成
3. 必要に応じて手直し
4. 「友人のみ」公開（会員限定）に設定
5. microCMS に URL を貼付
```

## 🔧 カスタマイズ

### トピック生成の基準を変更
`src/weekly-topic-generator.js` の `userPrompt` を編集

### 実行スケジュールを変更
`.github/workflows/weekly-topic-bot.yml` の cron 表記を編集

例）毎週金曜 10 時に実行したい場合：
```yaml
- cron: '0 1 * * 5'  # 金曜 UTC 1 時 = JST 10 時
```

## 📊 次のフェーズ

- [ ] Vercel で Webhook 受信機能（フェーズ 2）
- [ ] ドラフト自動生成機能（フェーズ 3）
- [ ] Notion ダッシュボード連携
- [ ] Instagram への自動スライド生成

## 🐛 トラブルシューティング

[IMPLEMENTATION_GUIDE.md](./IMPLEMENTATION_GUIDE.md) の「トラブルシューティング」を参照

## 📞 サポート

エラーが出た場合、以下を確認してください：
1. GitHub Actions ログを確認
2. Secrets が正しく登録されているか
3. Anthropic API の残高
4. LINE Channel Settings で Messaging API が有効になっているか

## 📝 ライセンス

MIT

---

**Created by KOI | GENT 記事量産化プロジェクト**
